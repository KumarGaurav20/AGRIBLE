//jshint esversion:6

const express = require("express");
const ejs = require("ejs");
const path = require("path");
var nodemailer = require('nodemailer');
const app = express();
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "views")));

app.get("/", function (req, res) {
    res.render("login");
});

app.get("/index", function (req, res) {
    res.render("index");
});

app.get("/header", function (req, res) {
    res.render("header");
});

app.get("/sponsors", function (req, res) {
    res.render("sponsors");
});

app.get("/charts", function (req, res) {
    res.render("chartjs");
});

app.get("/tables", function (req, res) {
    res.render("basic-table");
});

app.get("/login", function (req, res) {
    res.render("login");
});

app.get("/register", function (req, res) {
    res.render("register");
});




app.listen(3000, function () {
    console.log("Hey, this is the server speaking!");
});